function cardAction() {
    alert("Button clicked!");
  }